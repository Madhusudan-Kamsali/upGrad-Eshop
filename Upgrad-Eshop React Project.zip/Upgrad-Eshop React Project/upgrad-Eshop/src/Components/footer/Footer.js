import "./Footer.css";
import Typography from '@mui/material/Typography';
const Footer = () => (
	<footer className="footer">
		<div style={{display: 'flex', justifyContent: 'center'}}>
			<Typography variant="body2">Copyright © upGrad 2024.</Typography>
		</div>
	</footer>
);

export default Footer;